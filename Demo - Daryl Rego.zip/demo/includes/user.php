<?php
/**
 * User Class for account creation and login purpose
 */
class User
{
  private $con;

  function __construct()
  {
    include_once("../database/db.php");
    $db = new Database();
    $this->con = $db->connect();
  }

  /** Email Validation
   * This functions checked if the user is already registered
   */
    private function emailExists($email){
        $pre_stmt = $this->con->prepare("SELECT id FROM user WHERE email = ? ");
        $pre_stmt->bind_param("s",$email); // binding parameters, replacing ? with email variable, s stands for string
        $pre_stmt->execute() or die($this->con->error); //if anything is wrong, this query will let us know
        $result = $pre_stmt->get_result();
        if($result->num_rows > 0){
          return 1;
        }else {
          return 0;
        }

    }
    //function to create a user account
    public function createUserAccount($username,$email,$password,$usertype){
      //prepares statement to proctect application from sql attack
      if($this->emailExists($email)){
        return "EMAIL_ALREADY_EXISTS";
      }else{
        $pass_hash = password_hash($password,PASSWORD_BCRYPT,["cost"=>8]);
        $date = date("Y-m-d");
        $notes = "";
        $pre_stmt = $this->con->prepare("INSERT INTO `user`(`username`, `email`, `password`, `usertype`, `registration_date`, `last_login`, `notes`) VALUES (?,?,?,?,?,?,?)");
        $pre_stmt->bind_param("sssssss",$username,$email,$pass_hash,$usertype,$date,$date,$notes);
        $result = $pre_stmt->execute() or die ($this->con->error);
        if($result) {
          return $this->con->insert_id;
        }else{
            return "SOME_ERROR";
        }
      }
    }
    //function to store the log in detail into the database
    public function userLogin($email,$password){
      $pre_stmt = $this->con->prepare("SELECT id,username,password,last_login FROM user WHERE email = ?");
      $pre_stmt->bind_param("s",$email);
      $pre_stmt->execute() or die($this->con->error);
  		$result = $pre_stmt->get_result();

      if ($result->num_rows < 1){
        return "NOT_REGISTERD";
      }else{
        $row = $result->fetch_assoc();
        if (password_verify($password,$row["password"])) {
          $_SESSION["userid"] = $row["id"];
  				$_SESSION["username"] = $row["username"];
  				$_SESSION["last_login"] = $row["last_login"];

          $last_login = date("Y-m-d h:m:s");
  				$pre_stmt = $this->con->prepare("UPDATE user SET last_login = ? WHERE email = ?");
  				$pre_stmt->bind_param("ss",$last_login,$email);
  				$result = $pre_stmt->execute() or die($this->con->error);
  				if ($result) {
  					return 1;
  				}else{
  					return 0;
  				}
          # code...
        }else{
  				return "PASSWORD_NOT_MATCHED";
      }
    }
  }
}
//$user = new User();
//echo $user->createUserAccount("Regoo","daryl.rego1@gmail.com","abc123","Other");

//echo $user->userLogin("daryl.rego@gmail.com","abc123");
//echo $_SESSION["username"];
?>
