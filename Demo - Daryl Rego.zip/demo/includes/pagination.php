<?php

$con = mysqli_connect("localhost","root","","test");

function pagination($con,$table,$pno,$n){
  $query = $con->query("SELECT COUNT(*) as rows FROM ".$table);
  $row = mysqli_fetch_assoc($qury);
  $totalRecords = $row;
  //$totalRecords = 100000;
  $pageno = $pno;
  $noOfRecordsPerPage = $n;

  $last = ceil($totalRecords["rows"]/$noOfRecordsPerPage);

  echo "Total Pages:".$last."<br/>"

  $pagination = "";
 //
  if ($last != 1) {
    //the page number should be greater than 1 to have a previous button
    if ($pageno > 1) {
      $previous = "";
      $previous = $pageno - 1;
        $pagination .= "<a href='pagination.php?pageno=".$previous."'style='color:#333;'> Previous </a>";
    }
    //if the current page is 10, than it will display page 5,6,7,8,9
      for($i = $pageno - 5; $i< $pageno; $i++ ){
        //if the $i is greater than 0 only than the pages will be created
        if ($i > 0){
          $pagination .= "<a href='pagination.php?pageno=".$i."'> ".$i." </a>";
        }
      }
      //displays the current page
      $pagination .= "<a href='pagination.php?pageno=".$pageno."' style='color:#333;'> $pageno </a>";
      //display next pages after the current page
      for ($i=$pageno + 1; $i<=$last; $i++){
        $pagination .= "<a href='pagination.php?pageno=".$i."'> ".$i." </a>";
        //depending on the current page number it will add 6
        if ($i > $pageno + 5) {
          break;
        }
      }
      //the last page should be greater than page no to have next button
      if ($last > $pageno) {
        $next = $pageno + 1;
        $pagination .= "<a href='pagination.php?pageno=".$next."'style='color:#333;'>Next</a>";
      }
  }
  //limit 0,10
  //limit 10,10
  //array limit
  $limit = "LIMIT".($pageno - 1) * $noOfRecordsPerPage.",".$noOfRecordsPerPage;

  return ["$pagination"=>$pagination,"limit"=>$limit];
}
//echo pagination($con,"xxx",3,10);
if (isset($_GET["pageno"])) {
  $pageno = $_GET["pageno"];

  $table = "paragraph";

  $array = pagination($con,$table,$pageno,10);

  $sql = "SELECT * FROM ".$table." ".$array["limit"];

  $query = $con->query($sql);

  while ($row = mysqli_fetch_assoc($query)){
    echo "<div style='margin:0 auto;font-size:20px;'><b>".$row["pid"]."</b> ".$row["p_description"]."</div>";
  }
  echo $array["pagination"];
}


?>
