<?php
//constants for db connection
session_start();

define("HOST","localhost");
define("USER","root");
define("PASSWORD","");
define("DB","car_inv");

define("DOMAIN","http://localhost/demo/");


?>
