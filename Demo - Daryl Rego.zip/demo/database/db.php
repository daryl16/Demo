<?php
//database class to connect to the mysql server
class Database
{
  private $con;

  public function connect(){
    include_once("constants.php");
    $this->con = new Mysqli(HOST,USER,PASSWORD,DB);
    if ($this->con) {
      //echo "Database connected successfully";
      return $this->con;
    }
    return "DATABASE_CONNECTION_FAIL";
  }
}
//$db = new Database();
//$db->connect();

?>
