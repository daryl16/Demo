$(document).ready(function(){
  var DOMAIN = "http://localhost/demo/";
    $("#register_form").on("submit",function(){
      var status = false; //variable declaration
      var name = $("#username");
      var email = $("#email");
      var password1 = $("#password1");
      var password2 = $("#password2");
      var type = $("#userType");
      //var name_pattern = new RegExp(/^[A-Za-z ]+$/);
      var email_pattern = new RegExp(/^[a-z0-9_-]+(\.[a-z0-9_-]+)*@[a-z0-9_-]+(\.[a-z0-9_-]+)*(\.[a-z]{2,4})$/); //email regex
      //if loops
      if(name.val() == "" || name.val().length < 2){
        name.addClass("border-danger"); //red colour border over the input text. addClass in jquery function
        $("#user_error").html("<span class='text-danger'>Please enter a valid name</span>");
        status = false;
      }else{
        name.removeClass("border-danger"); //red colour border over the input text. addClass in jquery function
        $("#user_error").html("");
        status = true;
      }
      if(!email_pattern.test(email.val())){
        email.addClass("border-danger"); //red colour border over the input text. addClass in jquery function
        $("#email_error").html("<span class='text-danger'>Please enter a valid email</span>");
        status = false;
      }else{
        email.removeClass("border-danger"); //red colour border over the input text. addClass in jquery function
        $("#email_error").html("");
        status = true;
      }
      if(password1.val() == "" || password1.val().length < 9){
        password1.addClass("border-danger"); //red colour border over the input text. addClass in jquery function
        $("#pasword1_error").html("<span class='text-danger'>Please enter a suitable password (more than 9 characters)</span>");
        status = false;
      }else{
        password1.removeClass("border-danger"); //red colour border over the input text. addClass in jquery function
        $("#pasword1_error").html("");
        status = true;
      }
      if(password2.val() == "" || password2.val().length < 9){
        password2.addClass("border-danger"); //red colour border over the input text. addClass in jquery function
        $("#password2_error").html("<span class='text-danger'>Please enter a suitable password (more than 9 characters)</span>");
        status = false;
      }else{
        password2.removeClass("border-danger"); //red colour border over the input text. addClass in jquery function
        $("#password2_error").html("");
        status = true;
      }
      if(type.val() == ""){
        type.addClass("border-danger"); //red colour border over the input text. addClass in jquery function
        $("#type_error").html("<span class='text-danger'>Please choose a User type</span>");
        status = false;
      }else{
        type.removeClass("border-danger"); //red colour border over the input text. addClass in jquery function
        $("#type_error").html("");
        status = true;
      }
      if ((password1.val() == password2.val()) && status == true){
        $(".overlay").show();
        $.ajax({
          url : DOMAIN+"/includes/process.php",
  				method : "POST",
  				data : $("#register_form").serialize(),
          success : function(data){
            if (data == "EMAIL_ALREADY_EXISTS"){
              $(".overlay").hide();
              alert("Email is already used");
            }else if(data == "SOME_ERROR"){
              $(".overlay").hide();
              alert("Some error, try again");
            }else{
              $(".overlay").hide();
              window.location.href = encodeURI(DOMAIN+"/index.php?msg=Registered Successfully");
            }
          }
        })

      }else {
        password2.addClass("border-danger");
        $("#password2_error").html("<span class='text-danger'>Password is not matched</span>");
        status = true;
      }
    })

    //for login
    $("#login_form").on("submit",function(){
        var email = $("#log_email");
        var password = $("#log_password");
        var status = false;
        if (email.val() == "") {
            email.addClass("border-danger");
            $("#email_error").html("<span class='text-danger'>Please enter email address</span>");
            status = false;
        }else{
            email.removeClass("border-danger"); //red colour border over the input text. addClass in jquery function
            $("#email_error").html("");
            status = true;
          }
          if (password.val() == "") {
              password.addClass("border-danger");
              $("#password_error").html("<span class='text-danger'>Please enter password</span>");
              status = false;
          }else{
              password.removeClass("border-danger"); //red colour border over the input text. addClass in jquery function
              $("#password_error").html("");
              status = true;
          }
          if (status) {
            $(".overlay").show();
            $.ajax({
              url : DOMAIN+"/includes/process.php",
      				method : "POST",
      				data : $("#login_form").serialize(),
              success : function(data){
                if (data == "NOT_REGISTERD"){
                  $(".overlay").hide();
                  email.addClass("border-danger");
                  $("#email_error").html("<span class='text-danger'>Email does not exist</span>");
                }else if(data == "PASSWORD_NOT_MATCHED"){
                  $(".overlay").hide();
                  password.addClass("border-danger");
                  $("#password_error").html("<span class='text-danger'>Please enter valid password</span>");
                  status = false;
                }else{
                  $(".overlay").hide();
                  console.log(data);
                  //alert(data);
                  window.location.href = DOMAIN+"panel.php";
                }
              }
            })

          }
    })

    //fetch category
    fetch_category();
    function fetch_category(){
      $.ajax({
        url : DOMAIN+"/includes/process.php",
        method : "POST",
        data : {getCategory:1},
        success : function(data){
          var root = "<option value='0'>Root</option>";
          var choose = "<option value=''>Choose Category</option>";
          $("#parent_cat").html(root+data);
          $("#select_cat").html(choose+data);
          //alert(data);
        }
      })
    }
    //fetch brand
    fetch_brand();
    function fetch_brand(){
      $.ajax({
        url : DOMAIN+"/includes/process.php",
        method : "POST",
        data : {getBrand:1},
        success : function(data){
          var choose = "<option value=''>Choose Brand</option>";
          $("#select_brand").html(choose+data);
          //alert(data);
        }
      })
    }

    //add category_name
    $("#category_form").on("submit",function(){
      if ($("#category_name").val() == "") {
        $("#category_name").addClass("border-danger");
        $("#cat_error").html("<span class='text-danger'>Please enter a category</span>");
        }else{
          $.ajax({
    				url : DOMAIN+"/includes/process.php",
    				method : "POST",
    				data : $("#category_form").serialize(), //will serialize the form data
            success : function(data){//once it comes to the ajax code, run the function with data
                if (data == "CATEGORY_ADDED"){
                //  alert(data);
                      $("#category_name").removeClass("border-danger");
                      $("#cat_error").html("<span class='text-success'>New Category Added Successfully</span>");
                      $("#category_name").val("");
                      fetch_category();
              }else{
                alert(data);
              }
            }
          })
        }
    })

    //add brand name
    $("#brand_form").on("submit",function(){
		if ($("#brand_name").val() == "") {
			$("#brand_name").addClass("border-danger");
			$("#brand_error").html("<span class='text-danger'>Please Enter Brand Name</span>");
		}else{
			$.ajax({
				url : DOMAIN+"/includes/process.php",
				method : "POST",
				data : $("#brand_form").serialize(),
				success : function(data){
					if (data == "BRAND_ADDED") {
						$("#brand_name").removeClass("border-danger");
						$("#brand_error").html("<span class='text-success'>New Brand Added Successfully..!</span>");
						$("#brand_name").val("");
						fetch_brand();
					}else{
						alert(data);
					}

				}
			})
		}
	})

  //add products
  $("#product_form").on("submit",function(){
		$.ajax({
				url : DOMAIN+"/includes/process.php",
				method : "POST",
				data : $("#product_form").serialize(),
				success : function(data){
					if (data == "NEW_PRODUCT_ADDED") {
            alert("New Product Added Successfully..!");
						$("#product_name").val("");
						$("#select_cat").val("");
						$("#select_brand").val("");
						$("#product_price").val("");
						$("#product_qty").val("");
        }else{
          console.log(data);
          alert(data);
        }

      }
    })

  })

  //manage category
  manageCategory();
    function manageCategory(){
      $.ajax({
  				url : DOMAIN+"/includes/process.php",
  				method : "POST",
  				data : {manageCategory:1},
  				success : function(data){
  					$("#get_category").html(data);
        }
      })
    }
})
